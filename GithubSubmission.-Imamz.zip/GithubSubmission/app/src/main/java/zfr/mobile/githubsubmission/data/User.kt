package zfr.mobile.githubsubmission.data

data class User(
    val login: String,
    val id: Int,
    val avatar_url: String
)

