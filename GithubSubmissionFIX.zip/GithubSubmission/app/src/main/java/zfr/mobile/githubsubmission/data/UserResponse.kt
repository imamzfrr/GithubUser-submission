package zfr.mobile.githubsubmission.data

data class UserResponse(
    val items : ArrayList<User>
)

